package PrimerPaquete;

public interface iniciarMarcha {
    default public void iniciarMarcha(){
        System.out.println("Iniciando marcha");
    }
}
