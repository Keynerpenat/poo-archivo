package PrimerPaquete;

public interface Acelerar {
    default public void acelerarVehiculo(){
        System.out.println("Acelenrando el vehículo.");
    }
}
